import config
from peewee import *

database = MySQLDatabase(config.db_content_database, **{
    'port': config.db_port,
    'user': config.db_user,
    'host': config.db_host,
    'password': config.db_pass
})


class UnknownField(object):
    pass


class BaseModel(Model):
    class Meta:
        database = database


class XmlActivitiesContents(BaseModel):
    xml = TextField()

    class Meta:
        db_table = 'xml_activities_contents'


class Activities(BaseModel):
    activity_type = IntegerField(null=True)
    context = CharField(null=True)
    discr = IntegerField(index=True)
    euid = BigIntegerField()
    has_audio_content = IntegerField(null=True)
    has_audiosubmit_content = IntegerField(null=True)
    has_video_content = IntegerField(null=True)
    is_no_submit = IntegerField(null=True)
    is_teacher_graded = IntegerField()
    name = CharField()
    options = IntegerField()
    sort_order = IntegerField()
    time = TimeField(null=True)
    title = CharField(null=True)
    unit_euid = BigIntegerField(index=True)
    url = CharField(null=True)
    version = IntegerField()
    xml_activity_content = ForeignKeyField(db_column='xml_activity_content_id', null=True,
                                           rel_model=XmlActivitiesContents, to_field='id')

    class Meta:
        db_table = 'activities'


class ContentStructure(BaseModel):
    entity_type = IntegerField()
    euid = BigIntegerField()
    level = IntegerField()
    lft = IntegerField()
    rgt = IntegerField()
    root = IntegerField()
    version = IntegerField()

    class Meta:
        db_table = 'content_structure'

    @classmethod
    def fetch_by_root_euid(cls, euid):
        return cls.select(cls.euid, cls.rgt, cls.lft, cls.root)\
            .where(cls.euid == euid)\
            .order_by(-cls.rgt, -cls.root).limit(1)\
            .execute()

    @classmethod
    def fetch_structure(cls, root_id, rgt, lft):
        query = cls.select(cls.euid, cls.entity_type, cls.level).join(Activities, JOIN_LEFT_OUTER,
            on=cls.euid == Activities.euid).where(((cls.root == root_id) & (cls.rgt <= rgt)
            & (cls.lft >= lft) & (cls.entity_type << [1, 2]))
            & ((Activities.discr == 1 & Activities.options.bin_and(1) == 1) | (Activities.id.is_null())))

        return query.execute()


class Products(BaseModel):
    name = CharField()
    name_normalized = CharField(index=True)
    options = IntegerField(index=True)
    product_master_euid = BigIntegerField(index=True)

    class Meta:
        db_table = 'products'

    @classmethod
    def fetch_by_id(cls, ids):
        return cls.select().where(cls.id << ids).execute()


class Units(BaseModel):
    etext = IntegerField()
    euid = BigIntegerField()
    hidden = IntegerField()
    name = CharField()
    number = CharField()
    options = IntegerField(index=True)
    parent_euid = BigIntegerField(index=True, null=True)
    product_master_euid = BigIntegerField(index=True)
    short_name = CharField()
    sort_order = IntegerField()
    unit_activity_title = CharField(null=True)
    version = IntegerField()

    class Meta:
        db_table = 'units'

    @classmethod
    def fetch_euid_by_product_master(cls, master_id):
        return cls.select(cls.euid)\
            .where((cls.product_master_euid == master_id) & (cls.parent_euid.is_null()) & (cls.options.bin_and(1) == 1))
