

class Role(object):
    def __init__(self, roles=[], name=""):
        self.roles = roles
        self.name = name


class UserType(object):
    def __init__(self, name, type):
        self.type = type
        self.name = name