import config
from peewee import *

database = MySQLDatabase(config.db_database, **{
    'port': config.db_port,
    'user': config.db_user,
    'host': config.db_host,
    'password': config.db_pass
})


class UnknownField(object):
    pass


class BaseModel(Model):
    class Meta:
        database = database

    @classmethod
    def create_many(cls, data):
        with database.atomic():
            for idx in range(0, len(data), 1000):
                result = cls.insert_many(data[idx:idx+1000]).execute()
                if not result:
                    raise Exception
            return True


class Courses(BaseModel):
    code = CharField(unique=True)
    course_master = ForeignKeyField(db_column='course_master_id', null=True, rel_model='self', to_field='id')
    created_date = DateTimeField()
    expiration_date = DateTimeField()
    is_master = IntegerField(index=True)
    name = CharField()
    name_normalized = CharField()
    options = IntegerField(index=True)
    product = IntegerField(db_column='product_id')
    resource_settings = IntegerField(db_column='resource_settings_id')

    class Meta:
        db_table = 'courses'

    @classmethod
    def fetch_by_products(cls, products):
        return cls.select(cls.id, cls.product, cls.options).where((cls.product << products) & (cls.options.bin_and(1) == 1))\
            .execute()

    @classmethod
    def fetch_by_id(cls, ids):
        return cls.select(cls.id, cls.name, cls.product, cls.code).where(cls.id << ids).execute()

    @classmethod
    def fetch_by_code(cls, codes):
        return cls.select().where(cls.code << codes).execute()

class CourseSettings(BaseModel):
    course = ForeignKeyField(db_column='course_id', null=True, rel_model=Courses, to_field='id', unique=True)
    gse_thresholds = TextField()
    hidden_activities = TextField()
    hidden_units = TextField()
    number_of_attempts_before_correct_answer_is_shown_assignment = IntegerField()
    number_of_attempts_before_correct_answer_is_shown_practice = IntegerField()
    number_of_attempts_before_correct_answer_is_shown_test = IntegerField(null=True)
    number_of_attempts_for_each_activity_assignment = IntegerField()
    number_of_attempts_for_each_activity_practice = IntegerField()
    number_of_attempts_for_each_activity_test = IntegerField(null=True)
    options = IntegerField()
    remediation_threshold = IntegerField()
    score_to_gradebook_assignment = IntegerField()
    score_to_gradebook_practice = IntegerField(null=True)
    score_to_gradebook_test = IntegerField(null=True)
    thresholds = TextField()
    time_for_each_activity = CharField()

    class Meta:
        db_table = 'course_settings'

class Organization(BaseModel):
    name = CharField(index=True)
    rumba_organization = CharField()

    class Meta:
        db_table = 'organization'


class Users(BaseModel):
    country = IntegerField(null=True)
    current_course = ForeignKeyField(db_column='current_course_id', null=True, rel_model=Courses, to_field='id')
    date_format = IntegerField()
    email = CharField()
    firstname = CharField()
    fullname_normalized = CharField(index=True)
    homepage_tab_selected = IntegerField(null=True)
    last_login = DateTimeField(null=True)
    lastname = CharField()
    locale = IntegerField()
    marketing_information_enabled = IntegerField()
    middlename = CharField(null=True)
    native_language = IntegerField()
    options = IntegerField(index=True)
    organization = ForeignKeyField(db_column='organization_id', null=True, rel_model=Organization, to_field='id')
    password = CharField()
    registered_at = DateTimeField(null=True)
    rumba_user = CharField(db_column='rumba_user_id', index=True, null=True)
    salt = CharField()
    time_zone = IntegerField()
    username = CharField(unique=True)

    class Meta:
        db_table = 'users'

    @classmethod
    def fetch_by_usernames(cls, usernames):
        users = []

        with database.atomic():
            for idx in range(0, len(usernames), 1000):
                users.extend(cls.select().where(cls.username << usernames[idx:idx+1000]).execute())

        return users

    @classmethod
    def fetch_by_option_with_limit(cls, option, limit, type):
        query = cls.select(cls.id, cls.username, UsersCourses.course, Courses.product.alias("product")).dicts()\
            .join(UsersCourses).join(Courses, on=UsersCourses.course == Courses.id)\
            .where((cls.options.bin_and(option) == option) & (cls.options.bin_and(8192) == 0) & (UsersCourses.discr == type)).limit(limit)

        users = query.execute()

        cls.update(options=cls.options + 8192).where(cls.id << [user['id'] for user in users]).execute()

        return users


class UsersCourses(BaseModel):
    STUDENT = 1
    TEACHER = 2

    course = ForeignKeyField(db_column='course_id', null=True, rel_model=Courses, to_field='id')
    discr = IntegerField(index=True)
    enrol_date = DateTimeField(null=True)
    options = IntegerField(index=True)
    sort_order = IntegerField(null=True)
    user = ForeignKeyField(db_column='user_id', null=True, rel_model=Users, to_field='id')

    class Meta:
        db_table = 'users_courses'



class UsersRumbaProducts(BaseModel):
    expiration_date = DateTimeField()
    rumba_product = IntegerField(db_column='rumba_product_id')
    rumba_resource = IntegerField(db_column='rumba_resource_id')
    user = IntegerField(db_column='user_id')

    class Meta:
        db_table = 'users_rumba_products'
        primary_key = CompositeKey('expiration_date', 'rumba_product', 'rumba_resource', 'user')


class Roles(BaseModel):
    ROLE_STUDENT = 2
    ROLE_USER = 3
    ROLE_STUDENT_ADULT = 6
    student_roles = [ROLE_STUDENT, ROLE_USER, ROLE_STUDENT_ADULT]

    role = CharField(unique=True)

    class Meta:
        db_table = 'roles'

    @classmethod
    def fetch_roles(cls):
        return cls.select().execute()

    @classmethod
    def fetch_by_ids(cls, ids):
        return cls.select().where(cls.id << ids).execute()




class UsersRoles(BaseModel):
    role = ForeignKeyField(db_column='role_id', rel_model=Roles, to_field='id')
    user = ForeignKeyField(db_column='user_id', rel_model=Users, to_field='id')

    class Meta:
        db_table = 'users_roles'
        primary_key = CompositeKey('role', 'user')

