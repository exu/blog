import datetime
from http import HTTPStatus
import random
from bson.objectid import ObjectId

from model.dto import Role, UserType
from model.nmel import Users,database, UsersCourses, Courses
import json
import motor
from tornado import gen
from tornado.web import RequestHandler, HTTPError
from util.data_creator import UserCreator, UserCourseCreator, UserRolesCreator, UserRumbaProductCreator, ProductsMap, \
    CourseCreator, CourseSettingsCreator, UsersMongoUpdater, CourseDataGenerator
from util.product_data import ProductGenerator, UserGenerator, AnswerGenerator
import asyncio


class PeeweeRequestHandler(RequestHandler):
    def prepare(self):
        database.connect()
        return super(PeeweeRequestHandler, self).prepare()

    def on_finish(self):
        if not database.is_closed():
            database.close()
        return super(PeeweeRequestHandler, self).on_finish()

class MyRequestHandler(PeeweeRequestHandler):

    def initialize(self):
        self.mongo_db = self.settings['mongo_db']

class LandingHandler(MyRequestHandler):
    def data_received(self, chunk):
        pass


    async def get(self, user_id):
        users = Users.select().where(Users.id == user_id)

        if not users:
            raise HTTPError(HTTPStatus.NOT_FOUND, "User not found")

        return self.render('land.html', users=users)


class UsersHandler(MyRequestHandler):
    async def get(self):
        roles = [
            Role("2, 3, 8", "Student"),
            Role("5, 8", "Teacher")
        ]

        return self.render('create.html', roles=roles)



    async def post(self):
        roles = [int(role) for role in self.get_argument('radio_role').split(",")]

        amount = int(self.get_argument('usr_limit'))

        if {2, 3, 8}.issubset(set(roles)):
            discr = UsersCourses.STUDENT
            rumba_products = {'rumba_product': 3389, 'rumba_resource': 3160}
        else:
            discr = UsersCourses.TEACHER
            rumba_products = {'rumba_product': 3568, 'rumba_resource': 3164}

        users = UserCreator().create(amount=amount)

        course_ids = ProductsMap().get()
        users_mongo = UserCourseCreator().create(users, discr, course_ids)
        await self.mongo_db.user_data.insert(users_mongo)
        UserRolesCreator().create(users, roles)

        UserRumbaProductCreator().create(users, rumba_products)

        self.redirect("/users/create")


class GeneratedUsersHandler(MyRequestHandler):
    @gen.coroutine
    def get(self):
        fs = motor.MotorGridFS(self.settings['mongo_db'], "users")
        files = fs.find()
        data = []
        while (yield files.fetch_next):
            grid_out = files.next_object()
            data.append(grid_out)

        types = [UserType("Student without Course", UsersCourses.STUDENT), UserType("Teacher without Course", UsersCourses.TEACHER)]

        return self.render('users.html', files=data, user_types=types)


    async def post(self):
            limit = self.get_argument('usr_limit')
            user_type = self.get_argument('type')

            if not limit or not user_type:
                raise HTTPError(HTTPStatus.BAD_REQUEST, "Please set all fields")

            try:

                users_file = await UserGenerator(self.mongo_db).generate(int(limit), user_type)

                fs = motor.MotorGridFS(self.settings['mongo_db'], "users")
                try:
                    now = str(datetime.datetime.now().timestamp())
                    role = 'Student' if int(user_type) is UsersCourses.STUDENT else 'Teacher'
                    kwargs = {'filename': role+limit+'-'+now+'.csv', 'encoding': 'utf-8'}
                    gridin = await fs.new_file(**kwargs)
                    await gridin.write(users_file.getvalue())
                finally:
                    await gridin.close()
            finally:
                self.redirect("/users")


class UserFilesHandler(MyRequestHandler):
    @gen.coroutine
    def get(self, invoice_id, type):
        if not ObjectId.is_valid(invoice_id):
            raise HTTPError(HTTPStatus.BAD_REQUEST, "Invalid object_id string")
        fs = motor.MotorGridFS(self.settings['mongo_db'], type)
        users_file = yield fs.find_one({"_id": ObjectId(invoice_id)})

        if not users_file:
            raise HTTPError(HTTPStatus.NOT_FOUND)
        data = yield users_file.read()

        self.set_header('Content-Type', 'text/csv')
        self.set_header('Content-Disposition', 'attachment;filename='+users_file.filename)

        return self.write(data)


class GeneratedProductsHandler(MyRequestHandler):
    @gen.coroutine
    def get(self):
        fs = motor.MotorGridFS(self.settings['mongo_db'], 'products')
        all_files = fs.find()
        data = []
        while (yield all_files.fetch_next):
            grid_out = all_files.next_object()
            data.append(grid_out)

        return self.render('products.html', files=data)

    @gen.coroutine
    def post(self):

        products = ProductGenerator().generate()

        response = json.dumps(products, sort_keys=True, indent=4, ensure_ascii=False)
        fs = motor.MotorGridFS(self.settings['mongo_db'],'products')
        try:
            now = str(datetime.datetime.now().timestamp())
            kwargs = {'filename': 'product'+now+'.json', 'encoding': 'utf-8'}
            gridin = yield fs.new_file(**kwargs)
            yield gridin.write(response)
        finally:
            yield gridin.close()


        self.redirect("/products")


class EnrollUsersHandler(MyRequestHandler):
    @gen.coroutine
    def get(self):
        self.render('enroll.html')



    async def post(self):
        limit = int(self.get_argument('usr_limit'))
        user_partition = int(self.get_argument('usr_part'))
        cursor = await self.mongo_db.user_data.aggregate(
            [
                {"$match": {'type':UsersCourses.TEACHER, 'has_course':True, 'has_students': False}},
                {"$group": {'_id':"$product", "courses": {"$push": "$$ROOT.course"}}}
            ], cursor={}
        )
        courses_by_products = await cursor.to_list(None)

        try:
            for course_data in courses_by_products:

                cursor = self.mongo_db.user_data.find(
                    {'type': UsersCourses.STUDENT, 'has_course': False, 'generated': False, 'product': course_data['_id']}).limit(limit)
                mongo_users = await cursor.to_list(None)

                random.shuffle(mongo_users)
                index = 0
                course_ids = course_data['courses']
                random.shuffle(course_ids)
                course_limit = int(limit/user_partition)
                for course_id in course_ids[0:course_limit]:
                    if not course_id:
                        raise HTTPError(HTTPStatus.INTERNAL_SERVER_ERROR)
                    users = mongo_users[index:user_partition+index]
                    index += user_partition
                    UserCourseCreator().enrol_to_course(users, course_id)
                    for user in users:
                        await self.mongo_db.user_data.update(
                            {'_id': user['_id']},
                            {'$set': {'has_course': True, 'course': course_id}}
                        )
                    await self.mongo_db.user_data.update(
                        {'type': UsersCourses.TEACHER, 'has_students':False, 'course': course_id},
                        {'$set': {'has_students': True}}
                    )

        except:
            raise HTTPError(HTTPStatus.INTERNAL_SERVER_ERROR)

        self.render('enroll.html')


class CreateCoursesHandler(MyRequestHandler):
    @gen.coroutine
    def get(self):
        self.render('course_create.html')


    async def post(self):
        limit = int(self.get_argument('usr_limit'))
        cursor = self.mongo_db.user_data.find({'type': UsersCourses.TEACHER, 'has_course': False}).limit(limit)
        users = await cursor.to_list(None)
        course_data = CourseCreator().create(users)
        CourseSettingsCreator().create(course_data['courses'])

        mongo_users = UsersMongoUpdater().update(course_data['users'], course_data['courses'])


        UserCourseCreator().enrol_to_course(mongo_users)
        for user in mongo_users:
            await self.mongo_db.user_data.update(
                {'_id': user['_id']},
                {'$set': {'has_course': user['has_course'], 'course': user['course'], 'has_students': False}}
            )

        self.render('course_create.html')


class CreateCoursesDataHandler(MyRequestHandler):
    async def get(self):
        self.render("join_data_creator.html")


    async def post(self):
        course_ids = await self.mongo_db.user_data.find(
            {'type': UsersCourses.TEACHER, 'has_course': True, 'generated': False}, {'course': 1, '_id': 0}
        ).distinct('course')


        course_data = Courses.fetch_by_id(course_ids)

        mongo_data = CourseDataGenerator().create(course_data)

        await self.mongo_db.course_data.insert(mongo_data)

        self.render("join_data_creator.html")


class AnswersHandler(MyRequestHandler):
    async def get(self):
        data = await AnswerGenerator().create(80)

        json_data = json.dumps(data, sort_keys=True, indent=4, ensure_ascii=False)

        self.write(json_data)