from http import HTTPStatus
import random
from faker.factory import Factory
from model.nmel import Users, UsersCourses
from model.nmel_content import Products, Units, ContentStructure
from tornado.web import HTTPError
import util.file_util as file_data
import asyncio


class ProductGenerator(object):
    def generate(self):
        ids = list(file_data.load_file('products').keys())

        products = Products.fetch_by_id(ids)
        data = {}
        levels = {
            0: 'root_level',
            1: 'first_level',
            2: 'second_level',
            3: 'third_level',
            4: 'fourth_level',
            5: 'fifth_level'
        }

        for product in products:
            prod_data = {
                'activities': {
                    levels[0]: []
                },
                'units': {}
            }
            euids = Units.fetch_euid_by_product_master(product.product_master_euid)
            structures = ContentStructure.fetch_by_root_euid(euids)

            for structure in structures:
                items = ContentStructure.fetch_structure(structure.root, structure.rgt, structure.lft)
                for item in items:
                    if item.entity_type == 1:
                        if levels[item.level] not in prod_data['units']:
                            prod_data['units'][levels[item.level]] = []

                        prod_data['units'][levels[item.level]].append(str(item.euid))
                    else:
                        prod_data['activities'][levels[0]].append(str(item.euid))
            prod_data['id'] = str(product.id)
            prod_data['name'] = product.name
            data[product.name] = prod_data

        return data


class UserGenerator(object):
    def __init__(self, db):
        self.mongo_db = db


    async def generate(self, limit, user_type):
        data_cursor = await self.mongo_db.course_data.aggregate(
            [
                {"$match": {'type': int(user_type)}},
                {"$group": {'_id':"$product", "codes": {"$push": {"code": "$$ROOT.code", "name": "$$ROOT.name"}}}}
            ], cursor={}
        )
        data = await data_cursor.to_list(None)

        query = {'type': int(user_type), 'generated': False}

        if int(user_type) == UsersCourses.TEACHER:
            query['has_course'] = True

        cursor =  self.mongo_db.user_data.find(
            query
        ).limit(limit)
        clients = await cursor.to_list(None)

        try:
            data_file = file_data.generate_csv("all", clients, user_type, data)

            for user in clients:
                self.mongo_db.user_data.update(
                    {'_id': user['_id']},
                    {'$set': {'generated': True}}
                )
        except:
            raise HTTPError(HTTPStatus.INTERNAL_SERVER_ERROR)

        return data_file


class AnswerGenerator(object):
    async def create(self, limit):
        fake = Factory.create('en_GB')

        correct_responses = {
            "response[i_592399][RESPONSE_1]": "gets",
            "response[i_592399][RESPONSE_2]": "makes",
            "response[i_592400][RESPONSE_1]": "won't pass",
            "response[i_592400][RESPONSE_2]": "don't study",
            "response[i_592401][RESPONSE_1]": "will you ask",
            "response[i_592401][RESPONSE_2]": "need",
            "response[i_592402][RESPONSE_1]": "doesn't rain",
            "response[i_592402][RESPONSE_2]": "will you come",
            "response[i_592403][RESPONSE_1]": "'ll buy",
            "response[i_592403][RESPONSE_2]": "has",
            "response[i_593898][RESPONSE_1]": "They have never been to the United States",
            "response[i_593899][RESPONSE_1]": "He hasn't done his homework",
            "response[i_593900][RESPONSE_1]": "What have you done to your hair",
            "response[i_593905][RESPONSE_1]": "She's had many adventures in her life",
            "response[i_593907][RESPONSE_1]": "I've seen that film three times",
            "response[i_592419][RESPONSE_1]": "Choice_1",
            "response[i_592421][RESPONSE_1]": "Choice_2",
            "response[i_592422][RESPONSE_1]": "Choice_3",
            "response[i_592423][RESPONSE_1]": "Choice_1",
            "response[i_592424][RESPONSE_1]": "Choice_1",
            "response[i_592426][RESPONSE_1]": "word_3",
            "response[i_592426][RESPONSE_2]": "word_5",
            "response[i_592426][RESPONSE_3]": "word_4",
            "response[i_592426][RESPONSE_4]": "word_6",
            "response[i_592426][RESPONSE_5]": "word_1",
            "response[i_592426][RESPONSE_6]": "word_2",
            "response[i_592428][RESPONSE_1]": "word_3",
            "response[i_592428][RESPONSE_2]": "word_2",
            "response[i_592428][RESPONSE_3]": "word_5",
            "response[i_592428][RESPONSE_4]": "word_6",
            "response[i_592428][RESPONSE_5]": "word_4",
            "response[i_592428][RESPONSE_6]": "word_1",
            "response[i_593945][RESPONSE_2]": "Choice_4",
            "response[i_593945][RESPONSE_3]": "Choice_8",
            "response[i_593945][RESPONSE_4]": "Choice_12",
            "response[i_593945][RESPONSE_5]": "Choice_13",
            "response[i_593945][RESPONSE_6]": "Choice_18",
            "response[i_593958][RESPONSE_2]": "please",
            "response[i_593959][RESPONSE_1]": "shame",
            "response[i_593960][RESPONSE_1]": "well",
            "response[i_593960][RESPONSE_2]": "matter",
            "response[i_593963][RESPONSE_1]": "help",
            "response[i_593965][RESPONSE_1]": "done",
            "response[i_593967][RESPONSE_1]": "sorry",
            "response[i_593967][RESPONSE_2]": "mean",
            "response[i_593967][RESPONSE_3]": "all",
            "response[i_593967][RESPONSE_4]": "happen",
            "response[i_592456][RESPONSE_1]": "Have you heard their new album",
            "response[i_592457][RESPONSE_1]": "She has travelled across the desert",
            "response[i_592458][RESPONSE_1]": "Have you taken a photo of the waterfall",
            "response[i_592459][RESPONSE_1]": "A shop assistant has a tiring job"
        }

        incorrect_answers = {
            "response[i_592399][RESPONSE_1]": fake.word(),
            "response[i_592399][RESPONSE_2]": fake.word(),
            "response[i_592400][RESPONSE_1]": fake.word(),
            "response[i_592400][RESPONSE_2]": fake.word(),
            "response[i_592401][RESPONSE_1]": fake.word(),
            "response[i_592401][RESPONSE_2]": fake.word(),
            "response[i_592402][RESPONSE_1]": fake.word(),
            "response[i_592402][RESPONSE_2]": fake.word(),
            "response[i_592403][RESPONSE_1]": fake.word(),
            "response[i_592403][RESPONSE_2]": fake.word(),
            "response[i_593898][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_593899][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_593900][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_593905][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_593907][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_592419][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592421][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592422][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592423][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592424][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592426][RESPONSE_1]": "word_3",
            "response[i_592426][RESPONSE_2]": self.random_word(),
            "response[i_592426][RESPONSE_3]": self.random_word(),
            "response[i_592426][RESPONSE_4]": self.random_word(),
            "response[i_592426][RESPONSE_5]": self.random_word(),
            "response[i_592426][RESPONSE_6]": self.random_word(),
            "response[i_592428][RESPONSE_1]": "word_3",
            "response[i_592428][RESPONSE_2]": self.random_word(),
            "response[i_592428][RESPONSE_3]": self.random_word(),
            "response[i_592428][RESPONSE_4]": self.random_word(),
            "response[i_592428][RESPONSE_5]": self.random_word(),
            "response[i_592428][RESPONSE_6]": self.random_word(),
            "response[i_593945][RESPONSE_2]": self.random_choice(3, 6),
            "response[i_593945][RESPONSE_3]": self.random_choice(6, 9),
            "response[i_593945][RESPONSE_4]": self.random_choice(9, 12),
            "response[i_593945][RESPONSE_5]": self.random_choice(12, 15),
            "response[i_593945][RESPONSE_6]": self.random_choice(15, 18),
            "response[i_593958][RESPONSE_2]": fake.word(),
            "response[i_593959][RESPONSE_1]": fake.word(),
            "response[i_593960][RESPONSE_1]": fake.word(),
            "response[i_593960][RESPONSE_2]": fake.word(),
            "response[i_593963][RESPONSE_1]": fake.word(),
            "response[i_593965][RESPONSE_1]": fake.word(),
            "response[i_593967][RESPONSE_1]": fake.word(),
            "response[i_593967][RESPONSE_2]": fake.word(),
            "response[i_593967][RESPONSE_3]": fake.word(),
            "response[i_593967][RESPONSE_4]": fake.word(),
            "response[i_592456][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_592457][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_592458][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_592459][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True)
        }

        incorrect_answers_next = {
            "response[i_592399][RESPONSE_1]": fake.word(),
            "response[i_592399][RESPONSE_2]": fake.word(),
            "response[i_592400][RESPONSE_1]": fake.word(),
            "response[i_592400][RESPONSE_2]": fake.word(),
            "response[i_592401][RESPONSE_1]": fake.word(),
            "response[i_592401][RESPONSE_2]": fake.word(),
            "response[i_592402][RESPONSE_1]": fake.word(),
            "response[i_592402][RESPONSE_2]": fake.word(),
            "response[i_592403][RESPONSE_1]": fake.word(),
            "response[i_592403][RESPONSE_2]": fake.word(),
            "response[i_593898][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_593899][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_593900][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_593905][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_593907][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_592419][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592421][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592422][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592423][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592424][RESPONSE_1]": self.random_choice(0, 3),
            "response[i_592426][RESPONSE_1]": "word_3",
            "response[i_592426][RESPONSE_2]": self.random_word(),
            "response[i_592426][RESPONSE_3]": self.random_word(),
            "response[i_592426][RESPONSE_4]": self.random_word(),
            "response[i_592426][RESPONSE_5]": self.random_word(),
            "response[i_592426][RESPONSE_6]": self.random_word(),
            "response[i_592428][RESPONSE_1]": "word_3",
            "response[i_592428][RESPONSE_2]": self.random_word(),
            "response[i_592428][RESPONSE_3]": self.random_word(),
            "response[i_592428][RESPONSE_4]": self.random_word(),
            "response[i_592428][RESPONSE_5]": self.random_word(),
            "response[i_592428][RESPONSE_6]": self.random_word(),
            "response[i_593945][RESPONSE_2]": self.random_choice(3, 6),
            "response[i_593945][RESPONSE_3]": self.random_choice(6, 9),
            "response[i_593945][RESPONSE_4]": self.random_choice(9, 12),
            "response[i_593945][RESPONSE_5]": self.random_choice(12, 15),
            "response[i_593945][RESPONSE_6]": self.random_choice(15, 18),
            "response[i_593958][RESPONSE_2]": fake.word(),
            "response[i_593959][RESPONSE_1]": fake.word(),
            "response[i_593960][RESPONSE_1]": fake.word(),
            "response[i_593960][RESPONSE_2]": fake.word(),
            "response[i_593963][RESPONSE_1]": fake.word(),
            "response[i_593965][RESPONSE_1]": fake.word(),
            "response[i_593967][RESPONSE_1]": fake.word(),
            "response[i_593967][RESPONSE_2]": fake.word(),
            "response[i_593967][RESPONSE_3]": fake.word(),
            "response[i_593967][RESPONSE_4]": fake.word(),
            "response[i_592456][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_592457][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_592458][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True),
            "response[i_592459][RESPONSE_1]": fake.sentence(nb_words=6, variable_nb_words=True)
        }


        incorrect = 0
        responses = {}

        for response in correct_responses:
            do_correct = random.choice([True, False])
            limit_incorrect = limit - incorrect
            if do_correct or (limit_incorrect <= 0):
                answer = random.choice([incorrect_answers_next[response], correct_responses[response]])
            else:
                answer = incorrect_answers[response]
                incorrect+=1
            responses[response] = answer

        return responses

    def random_choice(self, lower_bound, upper_bound):
        choices = ["Choice_"+str(index) for index in range(1, 19)]
        return random.choice(choices[lower_bound:upper_bound])

    def random_word(self):
        return random.choice(["word_"+str(index) for index in range(1, 6) if index != 3])