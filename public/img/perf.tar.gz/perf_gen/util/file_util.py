import io
import json
import os
import random
import config
import csv
from model.nmel import UsersCourses


def load_file(file):
    path = os.path.join(config.BASE_PATH, 'data', file + '.json')

    if os.path.isfile(path):
        return json.load(open(path))

    raise FileNotFoundError


def generate_csv(specification, data, user_type, extra_data):
    output = io.StringIO()
    headings = load_file(specification)[user_type]
    products = load_file('products')
    writer = csv.DictWriter(output, fieldnames=headings, extrasaction='ignore')
    writer.writeheader()
    random.shuffle(data)
    for row in data:

        if extra_data:
            for extra_row in extra_data:
                if int(user_type) == UsersCourses.STUDENT and extra_row['_id'] == int(row['product']):
                    codes = random.choice(extra_row['codes'])
                    row['course_code'] = codes['code']
                    row['course_name'] = codes['name']

        row['product'] = products[str(row['product'])]
        row['course_id'] = row['course']
        writer.writerow(row)

    return output