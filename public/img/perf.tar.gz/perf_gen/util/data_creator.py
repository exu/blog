import datetime
import re
import traceback
from faker import Factory
from model.nmel import Users, UsersCourses, Courses, UsersRoles, UsersRumbaProducts, CourseSettings
import random
import util.file_util as file_data
import asyncio


class UserCreator:
    def create(self, amount):
        fake = Factory.create('en_GB')
        data = []
        usernames = []
        for _ in range(0, amount):
            username = fake.first_name() + fake.last_name() + fake.first_name()
            usernames.append(username)
            data.append({
                'username': username,
                'firstname': fake.first_name(),
                'lastname': fake.last_name(),
                'email': fake.free_email(),
                'organization': 1,
                'password': 'e5YXkiWiozCjXiowx+crP8uOtuNi7dqQCvYT7+cgMx8m16p/gapkI7IYigo8ZA0G0EYDW0o6cmLsWIUwBiFe0Q==',
                'salt': 'ex769ptqt80ssgo0os408sk88cssok4',
                'rumba_user': 'ffffffff5644788de4b0da659c26eff8',
                'homepage_tab_selected': 1,
                'registered_at': datetime.datetime.utcnow(),
                'marketing_information_enabled': 0,
                'options': 16,
                'fullname_normalized': fake.last_name() + fake.first_name(),
                'country': 616,
                'time_zone': 425,
                'native_language': 360,
                'locale': 112,
                Users.date_format: 0
            })
        random.shuffle(data)
        try:
            Users.create_many(data)
        except:
            return traceback.format_exc()
        else:
            return Users.fetch_by_usernames(usernames)


class ProductsMap:
    def get(self):
        products = file_data.load_file('products').keys()
        return Courses.fetch_by_products(list(products))


class UserCourseCreator:
    def create(self, users_ids, user_type, course_ids):
        data = []
        mongo_data = []
        for user_id in users_ids:
            course = random.choice(list(course_ids))
            user_doc = {
                'username': user_id.username,
                'id': user_id.id,
                'product': course.product,
                'course': course.id,
                'generated': False,
                'type': user_type,
                'has_course': False
            }


            data.append({
                UsersCourses.enrol_date: datetime.datetime.utcnow(),
                UsersCourses.options: 0,
                UsersCourses.user: user_id,
                UsersCourses.discr: user_type,
                UsersCourses.course: course.id,
                UsersCourses.sort_order: 0
            })

            mongo_data.append(user_doc)
        try:
            UsersCourses.create_many(data)
        except:
            return traceback.format_exc()
        else:
            return mongo_data

    def enrol_to_course(self, users, course_id=""):
        data = []
        for user in users:
            if course_id:
                course = course_id
            else:
                course = user['course']

            if int(user['type']) == UsersCourses.TEACHER:
                option = 4
            else:
                option = 0

            data.append(
                {
                    UsersCourses.enrol_date: datetime.datetime.utcnow(),
                    UsersCourses.options: option,
                    UsersCourses.user: user['id'],
                    UsersCourses.discr: user['type'],
                    UsersCourses.course: course,
                    UsersCourses.sort_order: 0
                }
            )

        try:
            UsersCourses.create_many(data)
        except:
            print(traceback.format_exc())
            raise
        else:
            return True

class UserRolesCreator:
    def create(self, users, roles_ids):
        data = []
        for user in users:
            for role_id in roles_ids:
                data.append({
                    UsersRoles.user: user.id,
                    UsersRoles.role: role_id
                })

        try:
            UsersRoles.create_many(data)
        except:
            return traceback.format_exc()
        else:
            return True


class UserRumbaProductCreator:
    def create(self, users_ids, rumba_products):
        data = []
        for user_id in users_ids:
            data.append({
                UsersRumbaProducts.user: user_id,
                UsersRumbaProducts.rumba_product: rumba_products['rumba_product'],
                UsersRumbaProducts.rumba_resource: rumba_products['rumba_resource'],
                UsersRumbaProducts.expiration_date: '2017-08-12 10:50:16'
            })
        try:
            UsersRumbaProducts.create_many(data)
        except:
            return traceback.format_exc()
        else:
            return True


class CourseCreator:
    def change(self, match):
        value = match.group(0)
        length = str(len(value) - 1)
        upgraded = length + 'x' + value

        return upgraded.zfill(len(upgraded) + (3 - len(length)))

    def name_normalize(self, name):
        return re.sub(r'\d+', self.change, name)

    def create(self, users):
        fake = Factory.create('en_GB')
        try:
            course_data = []
            course_codes = []
            for user in users:
                course_code = fake.uuid4()[4:23]
                course_name = fake.company()
                course_data.append({
                    Courses.name: course_name,
                    Courses.expiration_date: '2022-01-01 00:00:00',
                    Courses.created_date: datetime.datetime.utcnow(),
                    Courses.product: user['product'],
                    Courses.resource_settings: 1,
                    Courses.is_master: 0,
                    Courses.options: 16,
                    Courses.name_normalized: self.name_normalize(course_name),
                    Courses.code: course_code
                })
                course_codes.append(course_code)
                user['code'] = course_code

            Courses.create_many(course_data)
        except:
            raise traceback.format_exc()
        else:
            return {'courses': Courses.fetch_by_code(course_codes), 'users': users}


class CourseSettingsCreator:
    def create(self, courses):
        course_settings = []
        try:
            for course in courses:

                course_settings.append(
                    {
                        CourseSettings.time_for_each_activity: '1:00',
                        CourseSettings.score_to_gradebook_practice: 1,
                        CourseSettings.number_of_attempts_before_correct_answer_is_shown_practice: 2,
                        CourseSettings.number_of_attempts_for_each_activity_practice: 10000,
                        CourseSettings.score_to_gradebook_assignment: 1,
                        CourseSettings.number_of_attempts_before_correct_answer_is_shown_assignment: 2,
                        CourseSettings.number_of_attempts_for_each_activity_assignment: 10000,
                        CourseSettings.score_to_gradebook_test: 1,
                        CourseSettings.number_of_attempts_before_correct_answer_is_shown_test: 10000,
                        CourseSettings.number_of_attempts_for_each_activity_test: 1,
                        CourseSettings.thresholds: 'a:6:{i:0;a:3:{s:5:"value";s:1:"F";s:5:"limit";i:0;s:5:"color"' +
                                                   ';s:7:"#DC2100";}i:1;a:3:{s:5:"value";s:1:"E";s:5:"limit";i:12'+
                                                   ';s:5:"color";s:7:"#E43300";}i:2;a:3:{s:5:"value";s:1:"D";s:5:"limit";'+
                                                   'i:33;s:5:"color";s:7:"#E67100";}' +
                                                   'i:3;a:3:{s:5:"value";s:1:"C";s:5:"limit";i:44;s:5:'
                                                   '"color";s:7:"#DFC400";}i:' +
                                                   '4;a:3:{s:5:"value";s:1:"B";s:5:"limit";i:56;s:5:"color";s:7:"#B8BF28";}' +
                                                   'i:5;a:3:{s:5:"value";s:1:"A";s:5:"limit";i:72;s:5:"color";s:7:"#70A215";}}',
                        CourseSettings.hidden_units: 'a:0:{}',
                        CourseSettings.hidden_activities: 'a:0:{}',
                        CourseSettings.remediation_threshold: 0,
                        CourseSettings.gse_thresholds: 'a:0:{}',
                        CourseSettings.options: 1048576,
                        CourseSettings.course: course.id
                    }
                )

            CourseSettings.create_many(course_settings)
        except:
            return traceback.format_exc()
        else:
            return True

class UsersMongoUpdater:
    def update(self, users, courses):
        for user in users:
            for course in courses:
                if course.code == user['code']:
                    user['course'] = course.id
                    user['has_course'] = True

        return users


class CourseDataGenerator:
    def create(self, courses_data):
        data = []
        for course in courses_data:
            data.append({
                'type': UsersCourses.STUDENT,
                'code': course.code,
                'product': course.product,
                'name': course.name
            })
        return data