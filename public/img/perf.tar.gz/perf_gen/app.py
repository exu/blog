# -*- coding: utf-8 -*-
from os import path
import config
from peewee import MySQLDatabase
from tornado.httpserver import HTTPServer
from tornado.ioloop import IOLoop
from tornado.options import options, define
from tornado.web import Application
from routes.main import MainUrl
import motor

# IOLoop.configure('tornado.platform.asyncio.AsyncIOLoop')
define("port", default=8001, help="run on the given port", type=int)

settings = dict(
    static_path=path.join(path.dirname(path.dirname(__file__)), "static"),
    template_path=path.join(path.dirname(__file__), "templates"),
    xsrf_cookies=True,
    debug=True
)

handlers = MainUrl().get_routes()

application = Application(handlers, **settings)

if __name__ == "__main__":
    server = HTTPServer(application, no_keep_alive=True)
    if not settings['debug']:
        server.bind(options.port, 'localhost', 0, 2048)
        server.start(0)
        db = motor.MotorClient('localhost', 27017).nmel
        application.settings['mongo_db'] = db
        IOLoop.current().start()
    else:
        application.listen(options.port)
        db = motor.MotorClient('localhost', 27017).nmel
        application.settings['mongo_db'] = db
        IOLoop.current().start()
