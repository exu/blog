from tornado.web import url
from handlers.base_handlers import LandingHandler, UsersHandler, GeneratedUsersHandler, UserFilesHandler, \
    GeneratedProductsHandler, EnrollUsersHandler, CreateCoursesHandler, CreateCoursesDataHandler, AnswersHandler

__author__ = 'danielfryc'

class MainUrl:
    def __init__(self):
        pass

    def get_routes(self):

        return [
            url(r"/([0-9]+)", LandingHandler, name="land"),
            url(r"/users/create", UsersHandler, name="create"),
            url(r"/courses/enroll", EnrollUsersHandler, name="enroll"),
            url(r"/courses", CreateCoursesHandler, name="course_create"),
            url(r"/courses/data/create", CreateCoursesDataHandler, name="course_data_create"),
            url(r"/users", GeneratedUsersHandler, name="users"),
            url(r"/products", GeneratedProductsHandler, name="products"),
            url(r"/answers", AnswersHandler, name="answers"),
            url(r"/users/files/([0-9a-zA-Z]{24,})/([a-z]+)", UserFilesHandler, name="user_file"),
            # url(r"/invoices/([0-9a-zA-Z]{24,})", InvoiceHandler, name="invoice"),
            # # url(r"/invoices", InvoiceHandler, name="invoices"),
            # url(r"/invoices/new", InvoiceNewHandler, name="new_invoice")
        ]
