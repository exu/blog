import os

BASE_PATH = os.path.abspath(os.path.dirname(__file__))
db_user = 'root'
db_pass = ''
db_host = '127.0.0.1'
db_database = 'nmeluser'
db_content_database = 'nmelcontent'
db_port = 3306
